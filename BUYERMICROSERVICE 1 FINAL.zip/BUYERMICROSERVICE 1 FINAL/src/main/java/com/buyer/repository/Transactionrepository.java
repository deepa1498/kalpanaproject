package com.buyer.repository;

import com.buyer.Entity.Transaction;

public interface Transactionrepository {

	static void save(Transaction transaction) {
		// TODO Auto-generated method stub
		
	}

}
