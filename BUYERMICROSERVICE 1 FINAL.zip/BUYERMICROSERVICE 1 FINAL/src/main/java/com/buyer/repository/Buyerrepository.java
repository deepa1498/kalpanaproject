package com.buyer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.buyer.Entity.Buyer;

@Repository
public interface Buyerrepository extends JpaRepository<Buyer, Integer>{

  

}
