package com.buyer.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.buyer.Entity.Buyer;
import com.buyer.Entity.Cart;
import com.buyer.Entity.Purchasehistory;
import com.buyer.Entity.Transaction;
import com.buyer.repository.Buyerrepository;
import com.buyer.repository.Cartrepository;
import com.buyer.repository.Transactionrepository;




@Service
public class CartService {
	
	@Autowired
	private Cartrepository cartrepository;
	
	@Autowired
	private Buyerrepository buyerrepositorty;
	
	
	public List<Cart> getAllCartItems(Integer buyerId){
		return cartrepository.getAllCartItems(buyerId);
	}
	
	public Optional<Cart> addCartItem(Cart cart, Integer buyerId) {
		
		return buyerrepositorty.findById(buyerId).map(buyer -> {
			
			cart.setBuyerId(buyer);
			return cartrepository.save(cart);
		});
		
	}
	
	public String deleteCartItemById(Integer Id) {
		cartrepository.deleteById(Id);
		return "Item with cartId "+Id+" is deleted.";
	}
	
	public void emptyCart(Integer buyerId) {
	
		cartrepository.emptyCart(buyerId);
	}
	
	public Cart updateCart(Cart cart, Integer Id) {
		//Cart cart = null;
		Optional<Cart> cart1 = cartrepository.findById(Id);
		
		if(cart1.isPresent())
		{
		cart = cart1.get();
		//cart.setItemId(cart.getItemId());
	//	cart.setItemQuantity(cart.getItemQuantity());
		cart.setItemDescription(cart.getItemDescription());
		
		return cartrepository.save(cart);
		}
		return null;
			
	}
	
	public void checkout(int buyerid, Transaction transaction) {
		Optional<Buyer>buyer=buyerrepositorty.findById(buyerid);
		Purchasehistory purchase=null;
		//Transaction transaction=null;
		List<Cart>getAllItems = cartrepository.getAllCartItems(buyerid);
		transaction=new Transaction();
		transaction.setBuyer(buyer.get());
		transaction.setRemarks(transaction.getRemarks());
		transaction.setTransactionType(transaction.getTransactionType());
	Transactionrepository.save(transaction);
	for(Cart cart:getAllItems) {
		purchase=new Purchasehistory();
		purchase.setBuyer(buyer.get());
		purchase.setItemId(cart.getItemId());
		purchase.setItemnumber(cart.getNumberofItems());
	purchase.save(purchase);
	}
	}
}	
	

	
	
	





