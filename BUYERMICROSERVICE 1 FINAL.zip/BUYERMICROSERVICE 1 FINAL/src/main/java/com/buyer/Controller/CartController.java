
package com.buyer.Controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.buyer.Entity.Cart;
import com.buyer.Service.CartService;

@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartService cartService;
	@GetMapping(value = "/{bid}/getAllcart")
	public List<Cart> getAllCartItems(@PathVariable("bid")Integer buyerId) {
	return cartService.getAllCartItems(buyerId);
	}
	@PostMapping(value="/{bid}/addcart",produces = "application/json")
	public Cart addCartItem(@PathVariable("bid") Integer buyerId,@RequestBody Cart CartItem) {
		Optional<Cart> savedItem = cartService.addCartItem(CartItem, buyerId);
		return savedItem.get();
	}
	
	@DeleteMapping(value = "/{cartid}/deletebyid")
	public String deleteCartItem(@PathVariable("cartid") Integer Id) {
		return cartService.deleteCartItemById(Id);
	}
	
	@DeleteMapping(value = "/{bid}/deleteallcart")
	public void emptyCart(@PathVariable("bid") Integer buyerId) {
		cartService.emptyCart(buyerId);
	}
	
	@PutMapping(value = "/{cartid}/updatecart",produces = "application/json")
	public Cart updateCart(@RequestBody Cart CartItem,@PathVariable("cartid") Integer Id) {
		return cartService.updateCart(CartItem, Id);
	}

}
