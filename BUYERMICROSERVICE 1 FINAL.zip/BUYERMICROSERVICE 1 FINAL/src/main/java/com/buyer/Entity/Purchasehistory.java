
package com.buyer.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Purchasehistory {
	
	@Id
	private int purchasehistoryId;
	
	private int itemnumber;
	private String remarks;
	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private Buyer buyer;
	
	
	@ManyToOne
	@JoinColumn(name="sellerId")
    private Seller seller;
	
	@ManyToOne
	@JoinColumn(name="transactionId")
    private Transaction transaction;
	@ManyToOne
	@JoinColumn(name="itemId")
    private Items items;
	
	public int getPurchasehistoryId() {
		return purchasehistoryId;
	}

	public void setPurchasehistoryId(int purchasehistoryId) {
		this.purchasehistoryId = purchasehistoryId;
	}

	public int getItemnumber() {
		return itemnumber;
	}

	public void setItemnumber(int itemnumber) {
		this.itemnumber = itemnumber;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Buyer getBuyer() {
		return buyer;
	}

	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}

	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public Items getItems() {
		return items;
	}

	public void setItems(Items items) {
		this.items = items;
	}

	public void setItemId(int itemId) {
		// TODO Auto-generated method stub
	
	}

	public void save(Purchasehistory purchase) {
		// TODO Auto-generated method stub
		
	}

}
	


	