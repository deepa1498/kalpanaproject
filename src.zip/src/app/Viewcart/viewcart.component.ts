import { Component, OnInit } from '@angular/core';

import { ProductService } from '../product.service';
import { Item } from '../items';
import { viewCart } from '../viewcart';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
  constructor(private displaycart:ProductService) { }
item:Item[];
cart:viewCart[];
view:viewCart=new viewCart();
cart1:viewCart=new viewCart();

total=0;
  ngOnInit(): void {
      this.reloading();
  }
reloading()
{
    this.displaycart.displayCartItems().subscribe( Cart => this.cart=Cart);
    console.log(this.cart);
    
  }

  increase(cart1:viewCart){
    if(cart1.noOfItems!=1)
    {
    cart1.noOfItems-=1;
    console.log(cart1.cartId,cart1.itemId,cart1.noOfItems);
    
    this.displaycart.updateCartItem(cart1).subscribe(cart1=>this.cart1= cart1);
  }
}
/*  delete(i:number)
  {
    console.log("delete method"+i);
this.cart.deletecartitem(i).subscribe(I=>this.i=I,I=>{alert("Item is deleted.")});
 this.reloading();
  }*/

  delete(id:number)
  {
console.log(id);
this.displaycart.deleteItem(id).subscribe(cart1=>this.cart1= cart1);
  }
  
  checkout()
  {
  }



}
