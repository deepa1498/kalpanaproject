import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-login',
  templateUrl: './buyer-login.component.html',
  styleUrls: ['./buyer-login.component.css']
})
export class BuyerLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
