import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule  } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { HeaderComponent } from './header/header.component';
import { BuyerLoginComponent } from './buyer-login/buyer-login.component';
import { SellerLoginComponent } from './seller-login/seller-login.component';
import { AddItemComponent } from './add-item/add-item.component'; 

@NgModule({
  declarations: [
    AppComponent,
    ProductDetailsComponent,
    DisplaycartComponent,
    SearchproductComponent,
    BuyersignupComponent,
    SellersignupComponent,
    HeaderComponent,
    BuyerLoginComponent,
    SellerLoginComponent,
    AddItemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
