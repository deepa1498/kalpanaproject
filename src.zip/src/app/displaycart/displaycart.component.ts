import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {


  disCart:Cart[];
  constructor(private displaycart:ProductService) { }

  ngOnInit(): void {


    this.displaycart.displayCartItems().subscribe( disCart => this.disCart=disCart);
    console.log(this.disCart);
    
  }

}
