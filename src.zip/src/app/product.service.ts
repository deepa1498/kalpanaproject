import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { ViewCart } from './displaycart';



@Injectable({
  providedIn: 'root'
})
export class ProductService {
 
  private baseUrl = 'http://localhost:8385/items';



  constructor(private http: HttpClient) { }
  createBuyer(buyer: Object): Observable<Object>{

    return this.http.post(`http://localhost:8674/buyer/addBuyer`,buyer);
  }
  createSeller(seller: Object): Observable<Object>{
    console.log(seller);
    return this.http.post(`http://localhost:8680/seller/create`,seller);
  }

  getItems(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`http://localhost:8680/items/getallitems/itemname`);
  }
  addToCart(cart: ViewCart):Observable<any> {
return this.http.post(`http://localhost:8674/cart/13/addcart`,cart);


  }

displayCartItems(cart1:ViewCart) : Observable<any>{

return this.http.get(`http://localhost:8674/cart/13/getAllcart`);

}

deletecartitem(i: number): Observable<any> {
  return this.http.delete(`http://localhost:8674/cartid/deletebyid`);
}


}


