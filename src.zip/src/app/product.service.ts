import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Cart } from './cart';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8680/items';



  constructor(private http: HttpClient) { }
  createBuyer(buyer: Object): Observable<Object>{

    return this.http.post(`http://localhost:8386/buyer/addBuyer`,buyer);
  }
  createSeller(seller: Object): Observable<Object>{
    console.log(seller);
    return this.http.post(`http://localhost:8680/create/seller`,seller);
  }

  getitembyName(itemname: string) : Observable<any> {
    console.log(itemname);

    return this.http.get(`${this.baseUrl}/getallitem/${itemname}`);
  }
  addToCart(cart:Cart):Observable<any> {
return this.http.post(`http://localhost:8386/cart/1/addToCart`,cart);


  }

displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:8386/cart/1/getAll`);

}

}


