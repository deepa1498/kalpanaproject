package com.example.jpa.service;

import org.springframework.web.bind.annotation.PathVariable;

import com.example.jpa.model.BuyerEntity;
import com.example.jpa.model.Post;

public interface IBuyerService {
	
	BuyerEntity createBuyer(BuyerEntity buyer);
	BuyerEntity  updateBuyer(BuyerEntity buyer);
	void  deleteById(Integer buyerId );
	

}
