package com.example.jpa.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jpa.model.BuyerEntity;
import com.example.jpa.model.PurchaseHistory;
import com.example.jpa.model.ShoppingCart;
import com.example.jpa.model.TransactionEntity;
import com.example.jpa.repository.IBuyerDao;
import com.example.jpa.repository.ITransactionDao;
import com.example.jpa.repository.PurchaseDao;
import com.example.jpa.repository.ShoppingCartDao;
import com.example.jpa.response.CartResponse;

@Service
public class ShoppingCartService implements IShoppingCartService {

	@Autowired
	IBuyerDao buyerdao;
	
	@Autowired
	ShoppingCartDao shoppingcartdao;
	
	@Autowired
    TransactionImplementation transactionservice;
	
	@Autowired
	ITransactionDao transationdao;
    
	@Autowired
	PurchaseDao purchasedao;
	
	@Override
	public void DeleteItemIncart(Integer carditemId) {
		Optional<ShoppingCart> cartitem = shoppingcartdao.findById(carditemId);
		
	if(cartitem.isPresent())
	{
		shoppingcartdao.deleteById(carditemId);
		
	}
	}

	@Override
	public ShoppingCart UpdateCart(ShoppingCart shoppingcartitem, Integer CaritemtId) {
		
		Optional<ShoppingCart> cartitem = shoppingcartdao.findById(CaritemtId);
		ShoppingCart cart=null;
	if(cartitem.isPresent())
	{
		cart = cartitem.get();
		  cart.setNoOfItems(shoppingcartitem.getNoOfItems());
		      return shoppingcartdao.save(cart);
	}
		return null;
	}

	@Override
	public CartResponse updateItemqunatity(CartResponse cartresp) {
		
	ShoppingCart cart=new ShoppingCart();
	
	
	Optional<ShoppingCart> cartitem = shoppingcartdao.findById(cartresp.getCartId());
	 
	if(cartitem.isPresent())
	{
		cart = cartitem.get();
		cart.setPrice(cartresp.getPrice());
         cart.setNoOfItems(cartresp.getNoOfItems());
     
            shoppingcartdao.save(cart);
	}
	
      cartresp.setCartId(cart.getCartId());
      cartresp.setItemId(cart.getItemId());
      cartresp.setNoOfItems(cart.getNoOfItems());
      return cartresp;
		
		
		
	}

	
	

	@Override
	public Optional<ShoppingCart> addItemToCart(Integer buyerId, ShoppingCart shoppingcart) {
	    
		return buyerdao.findById(buyerId).map(buyer ->{
			shoppingcart.setBuyer(buyer);
			/*
			 * shoppingcart.setDescription(shoppingcart.getDescription());
			 * shoppingcart.setNoOfItems(shoppingcart.getNoOfItems());
			 * shoppingcart.setItemId(shoppingcart.getItemId());
			 */
			return shoppingcartdao.save(shoppingcart);
		});
		 
		
	}

	@Override
	public List<ShoppingCart> getAllCart(Integer BuyerId) {
		  
		
		/*
		 * Optional<BuyerEntity> buyer = buyerdao.findById(BuyerId); List<ShoppingCart>
		 * cart=null; if(buyer.isPresent()) { cart= shoppingcartdao.findAll();
		 * 
		 * } return cart ;
		 */
		return shoppingcartdao.getAllCartItems(BuyerId);
	
	}

	@Override
	public void emptyCart(Integer buyerId) {
		
		shoppingcartdao.emptyCart(buyerId);
		
	}

	@Override
	public TransactionEntity  CheckoutCart(Integer buyerid ,TransactionEntity transactionhistory) {
		
		Optional<BuyerEntity> buyer  = buyerdao.findById(buyerid);
		PurchaseHistory  purchase=null;
		TransactionEntity transaction=null;
		
		List<ShoppingCart> getAllItems = shoppingcartdao.getAllCartItems(buyerid);
		
		transaction = new TransactionEntity();
		
		float sum=0;
		
		 
		// TransactionEntity transactionHistory=null;
		for(ShoppingCart cart:getAllItems)
		{
			float cost=(float) cart.getPrice();
			 purchase = new PurchaseHistory();
			purchase.setBuyer(buyer.get());
			purchase.setItemId(cart.getItemId());
			purchase.setNumberOfItems(cart.getNoOfItems());
			purchase.setRemarks("success");
			purchase.setPrice(cart.getPrice());
			purchase.setTransactionHistory(transaction);
			purchasedao.save(purchase);
			sum=cost+sum;
			
		}
		
	
		transaction.setBuyerentity(buyer.get());
		transaction.setTotalamount(sum);
		transaction.setTranRemarks(transactionhistory.getTranRemarks());
		transaction.setTransactionType(transactionhistory.getTransactionType());
		   transaction = transationdao.save(transaction);
		   shoppingcartdao.emptyCart(buyerid);
		   return transaction;
		

		
	}

	
	
	
	

}
