package com.example.jpa.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.BuyerEntity;
import com.example.jpa.model.Post;
import com.example.jpa.service.BuyerService;

@RestController
public class BuyerController {
	
	@Autowired
	private BuyerService buyerservice;
	
	
	  @PostMapping("/buyer")
	    public BuyerEntity createBuyer(@Valid @RequestBody BuyerEntity buyer) {
	      
		  return buyerservice.createBuyer(buyer);
	    }

	    @PutMapping("/update")
	    public BuyerEntity updateBuyer(@RequestBody BuyerEntity buyer) {
	        return buyerservice.updateBuyer(buyer);	        
	    }


	
	  @DeleteMapping("/delete/{id}") 
	  public void deleteById(@PathVariable("id") int buyerId) {
		 
	        buyerservice.deleteById(buyerId);
	
	
	  }
}
