package com.example.jpa.repository;
import com.example.jpa.model.BuyerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface IBuyerDao extends JpaRepository<BuyerEntity, Integer>  {

	
	
	

	
}
