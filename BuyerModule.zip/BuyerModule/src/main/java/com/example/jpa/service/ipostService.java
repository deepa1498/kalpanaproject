package com.example.jpa.service;

public interface ipostService {

}
