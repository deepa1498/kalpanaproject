package com.example.jpa.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


@Entity
@Table(name="purchasehistory")
public class PurchaseHistory extends AuditModel implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseId;
	//private int transactionId;
	private int itemId;
	private int numberOfItems;
	//private Date dateItme;
	private String remarks;
	private double price;
	
	
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@ManyToOne /* (fetch = FetchType.LAZY) */
	    @JoinColumn(name = "buyerId", nullable = false)
	   @OnDelete(action = OnDeleteAction.CASCADE)
	private BuyerEntity buyer;
	  
	@ManyToOne /* (fetch = FetchType.LAZY) */
		@JoinColumn(name = "transaction_history_fk")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private TransactionEntity transactionHistory;

	public TransactionEntity getTransactionHistory() {
		return transactionHistory;
	}

	public void setTransactionHistory(TransactionEntity transactionHistory) {
		this.transactionHistory = transactionHistory;
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BuyerEntity getBuyer() {
		return buyer;
	}

	public void setBuyer(BuyerEntity buyer) {
		this.buyer = buyer;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [purchaseId=" + purchaseId + ", itemId=" + itemId + ", numberOfItems=" + numberOfItems
				+ ", remarks=" + remarks + ", buyer=" + buyer + ", transactionHistory=" + transactionHistory + "]";
	}
	 
	

}
