package com.example.jpa.service;

import java.util.List;

import java.util.Optional;


import com.example.jpa.model.BuyerEntity;
import com.example.jpa.model.ShoppingCart;
import com.example.jpa.model.TransactionEntity;
import com.example.jpa.repository.ShoppingCartDao;
import com.example.jpa.response.CartResponse;

public interface IShoppingCartService {

	void DeleteItemIncart(Integer carditemId);
	ShoppingCart UpdateCart(ShoppingCart shoppingcartitem,Integer CaritemtId);
	TransactionEntity CheckoutCart(Integer buyerid,TransactionEntity transactionhistory);
	Optional<ShoppingCart> addItemToCart(Integer buyerId,ShoppingCart shoppincart);
	List<ShoppingCart> getAllCart(Integer BuyerId);
	void emptyCart(Integer buyerId);
	CartResponse updateItemqunatity(CartResponse cart);
}
