package com.example.jpa.service;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.BuyerEntity;
import com.example.jpa.repository.IBuyerDao;

@Service
public class BuyerService implements IBuyerService {
	
	@Autowired
	private IBuyerDao buyerdao;
	
	
	  @Override public BuyerEntity createBuyer(BuyerEntity buyer) {
	  
	  return buyerdao.save(buyer);
	  }
	 

	@Override
	public BuyerEntity updateBuyer(BuyerEntity buyer) {

		Optional<BuyerEntity> buyerobject = buyerdao.findById(buyer.getBuyerId());
		BuyerEntity buyer1 = null;
		if(buyerobject.isPresent()) {
			buyer1 = buyerobject.get();
			buyer1.setUserName(buyer.getUserName());
			buyer1.setEmail(buyer.getEmail());
			buyer1.setMobileNumber(buyer.getMobileNumber());
			buyer1.setPassword(buyer.getPassword());
			 buyer1= buyerdao.save(buyer1);
		}
		return buyer1;
	
	}

	@Override
	public void deleteById(Integer buyerId) {
		Optional<BuyerEntity> buyerid = buyerdao.findById(buyerId);
		
		if(buyerid.isPresent())
		{
			buyerdao.deleteById(buyerId);
		}
		
		
	}


	
	
}
