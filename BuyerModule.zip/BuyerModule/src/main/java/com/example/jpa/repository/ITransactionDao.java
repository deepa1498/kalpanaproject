package com.example.jpa.repository;

import java.util.Optional;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.jpa.model.TransactionEntity;

//import com.cts.Entity.TransactionEntity;

@Repository
public interface ITransactionDao extends JpaRepository<TransactionEntity, Integer> {
	
	  
	/*
	 * Page<TransactionEntity> findBybuyerentity(Integer buyerId, Pageable
	 * pageable);
	 */
	/*
	 * Optional<TransactionEntity> findByIdAndbuyerId(Integer transactionId, Integer
	 * buyerId);
	 */	 
}
