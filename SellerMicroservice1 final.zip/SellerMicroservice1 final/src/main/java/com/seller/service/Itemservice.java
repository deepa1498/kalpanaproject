package com.seller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.seller.Repository.Itemsrepository;
import com.seller.entity.Items;
import com.seller.entity.SearchItem;


@Service
public class Itemservice {
    @Autowired
	private Itemsrepository itemrepository;
	public  List<Items> getAllitem() {
		
		return itemrepository.findAll();
	}
		public Items addItem(Items newitems) {
			// TODO Auto-generated method stub


			return itemrepository.save(newitems);
			
	}
	
	//public List<Items> getitembyName(String itemname) {
			// TODO Auto-generated method stub
			//return  itemrepository.finditem(itemname);
		
		/*public Items updateItems() {
			return Itemsrepository.update(updateitem);
		
		}*/
	public List<Items> getitembyName(String itemname)//SearchItem items) 
	{
		
		//return itemrepository.finditem(items.getSearchItems().toLowerCase());
		return itemrepository.finditem(itemname);
				
	}
		
		
		}
		
		

