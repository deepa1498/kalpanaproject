package com.seller.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.seller.entity.Items;





@Repository
public interface Itemsrepository extends JpaRepository<Items, Integer>{

	
/*	@Query(value ="DELETE FROM items_table_seller WHERE item_table_seller.seller_id_fk = :Sellerid",nativeQuery= true )
	public void emptyitem(@Param("Sellerid")Integer sellerId,@Param("itemid")Integer SellerId);*/
	/*public  List<Items> findItem(String itemname) {
		// TODO Auto-generated method stub
		return Itemsrepository.findItem(itemname);
	}*/
	
	@Query(value = "from Items WHERE lower (itemName) like %:itemName%")
	public List<Items> finditem(@Param("itemName") String items);
	
}
