package com.seller.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



@Entity
public class Subcategory implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer subCategoryId;
	private String subCategoryName;
	
	private String briefDetail;
	private String gstpercent;
	@ManyToOne
	@JoinColumn(name="Category_id")
	 private  Category category;
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Integer getSubCategoryId() {
		return subCategoryId;
	}
	public void setSubCategoryId(Integer subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	public String getSubCategoryName() {
		return subCategoryName;
	}
	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}
	
	public String getBriefDetail() {
		return briefDetail;
	}
	public void setBriefDetail(String briefDetail) {
		this.briefDetail = briefDetail;
	}
	public String getGstpercent() {
		return gstpercent;
	}
	public void setGstpercent(String gstpercent) {
		this.gstpercent = gstpercent;
	}
	
}