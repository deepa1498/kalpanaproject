package com.seller.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Seller implements Serializable {
	
	@Id
	@GeneratedValue
	
	private int Sellerid;
	private String Sellername;
	private String Sellerpass;
	private String Sellercompanyname;
	//private string gstregnum;
	private String companydescription;
	private String Selleraddress;
	private String SellerWebsite;
	private String Selleremail;
	private String  Sellermobile;
	public Seller() {}
	
	public int getSellerid() {
		return Sellerid;
	}
	public void setSellerid(int sellerid) {
		Sellerid = sellerid;
	}
	public String getSellername() {
		return Sellername;
	}
	public void setSellername(String sellername) {
		Sellername = sellername;
	}
	public String getSellerpass() {
		return Sellerpass;
	}
	public void setSellerpass(String sellerpass) {
		Sellerpass = sellerpass;
	}
	public String getSellercompanyname() {
		return Sellercompanyname;
	}
	public void setSellercompanyname(String sellercompanyname) {
		Sellercompanyname = sellercompanyname;
	}
	public String getCompanydescription() {
		return companydescription;
	}
	public void setCompanydescription(String companydescription) {
		this.companydescription = companydescription;
	}
	public String getSelleraddress() {
		return Selleraddress;
	}
	public void setSelleraddress(String selleraddress) {
		Selleraddress = selleraddress;
	}
	public String getSellerWebsite() {
		return SellerWebsite;
	}
	public void setSellerWebsite(String sellerWebsite) {
		SellerWebsite = sellerWebsite;
	}
	public String getSelleremail() {
		return Selleremail;
	}
	public void setSelleremail(String selleremail) {
		Selleremail = selleremail;
	}
	public String getSellermobile() {
		return Sellermobile;
	}
	public void setSellermobile(String sellermobile) {
		Sellermobile = sellermobile;
	}
	public Seller(int sellerid, String sellername, String sellerpass, String sellercompanyname,
			String companydescription, String selleraddress, String sellerWebsite, String selleremail,
			String sellermobile) {
		super();
		Sellerid = sellerid;
		Sellername = sellername;
		Sellerpass = sellerpass;
		Sellercompanyname = sellercompanyname;
		this.companydescription = companydescription;
		Selleraddress = selleraddress;
		SellerWebsite = sellerWebsite;
		Selleremail = selleremail;
		Sellermobile = sellermobile;
	}
	@Override
	public String toString() {
		return "Seller [Sellerid=" + Sellerid + ", Sellername=" + Sellername + ", Sellerpass=" + Sellerpass
				+ ", Sellercompanyname=" + Sellercompanyname + ", companydescription=" + companydescription
				+ ", Selleraddress=" + Selleraddress + ", SellerWebsite=" + SellerWebsite + ", Selleremail="
				+ Selleremail + ", Sellermobile=" + Sellermobile + "]";
	}
	
	
	
	
	

}
