package com.seller.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.seller.entity.Items;
import com.seller.entity.SearchItem;
import com.seller.service.Itemservice;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/items")
public class Itemcontroller {
	@Autowired
	private Itemservice itemservice;

	@RequestMapping("/Items")
	public List<Items> getAllItem() {
		return itemservice.getAllitem();
	}

	@PostMapping("/additems/{sid}")
	public Items additem(@PathVariable(value = "sid") int sid, @RequestBody Items items) {
		return itemservice.addItem(items);
	}
	/*
	 * @PostMapping(value = "/{sid}/update",produces ="application/json") public
	 * Items updateItems(@PathVariable(value="sid") int sid, @RequestBody Items
	 * items) {
	 * 
	 * return itemservice.updateItems(sid,items); }
	 */

	
	  @RequestMapping(value = "/getallitem/{itemname}",produces ="application/json")
	  public List<Items> searchitem(@PathVariable("itemname") String itemname)//@RequestBody SearchItem items)
	  { 
		  return  itemservice.getitembyName(itemname);
		  }
	 

}
