package com.example.jpa.Controller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.SModel.Item;
import com.example.jpa.Serive.ItemSeriveImplementation;

@CrossOrigin(origins="*")
@RequestMapping("/itemapi")
@RestController
public class ItemController {
	
	
	@Autowired
	ItemSeriveImplementation itemSerivceImpl;
	
	@GetMapping("/getallbyname/{itemname}")
	public List<Item> getAllByitemName(@PathVariable("itemname") String itemname)
	{
		return itemSerivceImpl.getAllByitemName(itemname);
	}
	@PostMapping("/additem/{id}")
	public Optional<Item> addItem(@PathVariable("id") Integer sellerid, @RequestBody Item item)
	{
		return itemSerivceImpl.addItem(item, sellerid);
	}
	
	@PutMapping("/update/{id}")
	public Item updateItem(@PathVariable("id") Integer id,Item item)
	{
		return itemSerivceImpl.updateItem(item, id);
	}
	
	@GetMapping("/item/getall/{sellerid}")
	public List<Item> getAllBysellerid(@PathVariable("sellerid") Integer id)
	{
		return itemSerivceImpl.getAllBysellerid(id);
	}
	
	@GetMapping("/item/{itemid}")
	public Item getbyid(@PathVariable("itemid") Integer id)
	{
		return itemSerivceImpl.getbyid(id);
	}
	
	@DeleteMapping("/deleteitem/{id}")
	public void deleteItem(@PathVariable("id")Integer itemid)
	{
		 itemSerivceImpl.deleteItem(itemid);
	}
	
	@GetMapping("/getbysubid/{id}")
	public List<Item> getitemsbysubcategoryid(@PathVariable("id") Integer subid)
	{
		return itemSerivceImpl.getBysubcategoryid(subid);
	}

}
