package com.example.jpa.SRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.jpa.SModel.Item;

@Repository
public interface ItemDao extends JpaRepository<Item, Integer> {
	

	@Query(value = "SELECT * FROM Item item WHERE item.seller_id = :sellerId"	,nativeQuery = true)
	List<Item> getAllItemsBysellerid(@Param("sellerId")Integer sellerId);
	
	@Query(value="SELECT * FROM Item item WHERE lower(item.item_name) LIKE %:itemname%",nativeQuery = true)
	  List<Item> getAllByitemName(@Param("itemname") String itemname);
	
	
	@Query(value="SELECT * FROM Item item WHERE item.subcategoryid= :subcategoryid",nativeQuery=true)
	List<Item> getBysubcatogoryType(@Param("subcategoryid") int subcategoryid);
	
}

