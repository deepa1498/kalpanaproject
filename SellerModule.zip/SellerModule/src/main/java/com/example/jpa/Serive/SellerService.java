package com.example.jpa.Serive;

import java.util.List;

import com.example.jpa.SModel.SellerEntity;

public interface SellerService {

	SellerEntity addSeller(SellerEntity seller);
	SellerEntity updateSeller(SellerEntity seller,Integer id);
	List<SellerEntity> gettAll();
	 SellerEntity getById(Integer id);
	
	
}
