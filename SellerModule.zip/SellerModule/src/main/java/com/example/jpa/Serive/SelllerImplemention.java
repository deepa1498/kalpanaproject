package com.example.jpa.Serive;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jpa.SModel.Item;
import com.example.jpa.SModel.SellerEntity;
import com.example.jpa.SRepository.SellerDao;

@Service
public class SelllerImplemention  implements SellerService {

	@Autowired
	SellerDao sellerdao;
	@Override
	public SellerEntity addSeller(SellerEntity seller) {
		
		return sellerdao.save(seller);
	}

	@Override
	public SellerEntity updateSeller(SellerEntity seller, Integer id) {
		
		Optional<SellerEntity> sellerobject=sellerdao.findById(id);
		SellerEntity  sellerinsert=null;
		if(sellerobject.isPresent())
		{  sellerinsert= sellerobject.get();
			sellerinsert.setUsername(seller.getUsername());
			sellerinsert.setPassword(seller.getPassword());
			sellerinsert.setCompanyname(seller.getCompanyname());
			sellerinsert.setGstin(seller.getGstin());
			sellerinsert.setBriefaboutcompany(seller.getBriefaboutcompany());
			sellerinsert.setWebsite(seller.getWebsite());
			sellerinsert.setEmailId(seller.getEmailId());
			sellerinsert.setContactnumber(seller.getContactnumber());
			sellerinsert.setPostaladdress(seller.getPostaladdress());
			
			sellerinsert = sellerdao.save(sellerinsert);
		}
		return sellerinsert;
		
	}

	@Override
	public List<SellerEntity> gettAll() {
		
		return sellerdao.findAll();
	}

	@Override
	public SellerEntity getById(Integer id) {
	
		Optional<SellerEntity> seller = sellerdao.findById(id);
		 return seller.isPresent() ? seller.get(): null;
	}
	

	

	
}
