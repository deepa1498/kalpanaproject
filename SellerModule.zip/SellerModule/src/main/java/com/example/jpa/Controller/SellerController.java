package com.example.jpa.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.SModel.SellerEntity;
import com.example.jpa.Serive.SelllerImplemention;

@CrossOrigin(origins = "*")
@RequestMapping("/api")
@RestController
public class SellerController {
	
	@Autowired
	SelllerImplemention sellerSerivceimpl;
	
	
	@PostMapping("/addseller")
	public SellerEntity addSeller(@RequestBody SellerEntity seller)
	{
		
	       return sellerSerivceimpl.addSeller(seller);	
	}
	
	@PutMapping("/{sellerid}/seller")
	public SellerEntity updateSeller(@PathVariable("sellerid") Integer sellerid,@RequestBody SellerEntity seller)
	{
		return sellerSerivceimpl.updateSeller(seller, sellerid);
	}
	
	@GetMapping("/getall")
	public List<SellerEntity> gettAll()
	{
		return sellerSerivceimpl.gettAll();
	}
	
	@GetMapping("/seller/{id}")
	public SellerEntity getById(@PathVariable("id") Integer id)
	{
		return sellerSerivceimpl.getById(id);
	}
	
	
	
	

}
