import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { SellerService } from '../seller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-item',
  templateUrl: './update-item.component.html',
  styleUrls: ['./update-item.component.css']
})
export class UpdateItemComponent implements OnInit {

  constructor(private dataserv:SellerService,private router:Router) { }

  item:Item=new Item();
id:number;


  receiveMessage($event: number) {
    this.id = $event
  }
  
  ngOnInit(): void {

   this.dataserv.getall(1).subscribe(item=>this.item=item);
   console.log(this.item);
  }

  Update()
  {


    this.dataserv.updateItem(1,this.item).subscribe(data=>this.item=data,error => console.log(error));
  }
  onSubmit() {
    this.Update();  
    this.gotoList();  
  }

  gotoList() {
    this.router.navigate(['productlist']);
  }

}
