import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Seller } from './Seller';
import { Observable } from 'rxjs';
import { Item } from './Item';

@Injectable({
  providedIn: 'root'
})
export class SellerService {


 
  private baseUrl='http://localhost:8917/api/addseller'
  private baseUrl1='http://localhost:8917/itemapi/additem/1'

  constructor(private http:HttpClient) { }

  createSeller(seller:Seller):Observable<any>
  {
    return this.http.post(`${this.baseUrl}`,seller);
  }


   addItem(item:Item):Observable<any>
   {
     return this.http.post(`${this.baseUrl1}`,item);
   }

   getall(id:number):Observable<any>
  {
   return this.http.get(`http://localhost:8917/itemapi/item/getall/${id}`)
  }
 
   updateItem(itemid:number,item:Item):Observable<any>
   {
     return this.http.put(`http://localhost:8917/itemapi//update/4/${itemid}`,item);

   }
}
