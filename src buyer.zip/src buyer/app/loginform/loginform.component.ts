import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-loginform',
  templateUrl: './loginform.component.html',
  styleUrls: ['./loginform.component.css']
})
export class LoginformComponent implements OnInit {
  loginForm: FormGroup;
  invalidLogin: boolean = false;
  username: string;
  password: string;

  constructor(private formBuilder: FormBuilder, private router: Router, private  productservice:ProductService) { }
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }

  //
  

  login()
  {
    console.log("in login method");
    const loginPayload = {
      username: this.username,
      password: this.password
  }
  
    this.productservice.login(loginPayload).subscribe(data => {
      debugger;
      if(data.result.token!==null) {
    alert("success");
  
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('id', data.result.buyerId);
        window.localStorage.setItem('username', data.result.username);
     console.log(data.result.token);
        this.router.navigate(['homepage']);
      }else {
        //this.invalidLogin = true;
        alert("incorrectPasword");
      }
    });
  }

}




