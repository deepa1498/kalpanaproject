export class TransactionEntity1
{
    
    
    transactionId:number;
    tranRemarks:string;
    transactionType:string;
    totalamount:number;
}

export class TransactionEntity
{
    
    transactionId:number;
    totalamount:number;
    tranRemarks:string;
    transactionType:string;
}