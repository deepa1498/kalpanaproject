import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Item } from '../Item';
import { StringMap } from '@angular/compiler/src/compiler_facade_interface';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {

searchStr:string;
  constructor(private dataservice:ProductService) { }

  item:Item[];
  ngOnInit(): void {
  this.searchStr=" ";
  }

  searchitem()
  {

    this.dataservice.getItem(this.searchStr).subscribe(item=>this.item=item);

  }

  onSubmit()
  {
    this.searchitem();
  }

}
